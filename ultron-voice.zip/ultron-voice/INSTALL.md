# ULTRON voice add-on (Jarvis + Megatron)

1. Copy these into your project, keeping the folder structure:
   - app/api/tts/route.ts
   - components/VoicePanel.tsx
   (If your project has no `app/` folder at the root but `src/app/`, put them under `src/` instead.)

2. Create `.env.local` in the project root:
   ELEVENLABS_API_KEY=your_key_here

3. Open `app/page.tsx` and add:
   import VoicePanel from "@/components/VoicePanel";   // or "../components/VoicePanel"
   ...and render <VoicePanel /> inside the page's returned JSX.

4. Add both voices to your ElevenLabs account (Jarvis + Megatron share links), then:
   npm run dev   ->   open the URL it prints.

Optional: make the orb react to the voice. VoicePanel fires a `ultron:level` event (0 to 1):
   window.addEventListener("ultron:level", (e) => console.log((e as CustomEvent).detail));
